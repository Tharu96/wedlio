<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Receptions extends CI_Controller {

	public function __constructor(){
		
	}
	
	

	public function cinnamon_grand()
	{
		$this->load->view('cinnamon_grand');
	}
} ?>