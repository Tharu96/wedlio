-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 07, 2020 at 12:21 AM
-- Server version: 10.1.29-MariaDB
-- PHP Version: 7.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `wedlio`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `UserId` int(11) NOT NULL,
  `firstName` int(11) NOT NULL,
  `lastName` int(11) NOT NULL,
  `address` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `userId` varchar(255) NOT NULL,
  `birthdate` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`userId`, `birthdate`, `gender`, `created_at`) VALUES
('CUS001', '06-04-1996', 'female', '2019-11-19 00:00:00'),
('CUS003', '1996-04-01', 'Female', '2019-11-19 07:57:26'),
('CUS004', '1997-01-02', 'Female', '2019-11-19 08:04:55'),
('CUS005', '1996-06-07', 'Female', '2019-11-19 09:01:02');

-- --------------------------------------------------------

--
-- Table structure for table `photography`
--

CREATE TABLE `photography` (
  `vendorId` int(10) NOT NULL,
  `categoryId` int(100) NOT NULL,
  `startingPriceRange` varchar(255) NOT NULL,
  `photoShootTypes` varchar(255) NOT NULL,
  `weddingActivities` varchar(255) NOT NULL,
  `photoAndVideo` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `userId` varchar(255) NOT NULL,
  `firstName` varchar(255) NOT NULL,
  `lastName` varchar(255) NOT NULL,
  `contactNo` varchar(255) NOT NULL,
  `NIC` varchar(100) NOT NULL,
  `Image` varchar(255) DEFAULT NULL,
  `address` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `encrypted_password` varchar(255) NOT NULL,
  `status` varchar(50) NOT NULL,
  `user_role` varchar(50) NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`userId`, `firstName`, `lastName`, `contactNo`, `NIC`, `Image`, `address`, `username`, `encrypted_password`, `status`, `user_role`, `created_at`) VALUES
('CUS001', 'Sashini', 'Tharuka', '077458962', '965874010v', 'upload/customer/965874010v.jpg', 'Galle', 'sashini@gmail.com', 'abc', '1', 'customer', '2019-11-19 00:00:00'),
('CUS003', 'Miyuru', 'Abhegunawardhana', '0774589621', '974589015v', './uploads/customer/974589015v.jpg', '67, Galle Road, Aluthgama', 'miyuruab@gmail.com', '$2y$10$nIG9QuLjkHxREb8vx39ct.a3YlM1rARsPdi46Ydql5AES5vkGVfjW', '1', 'customer', '2019-11-19 07:57:26'),
('CUS004', 'Damsara', 'Ranasinghe', '0112457824', '970293191V', './uploads/customer/970293191V.jpg', 'Nitambuwa', 'damsarar@gmail.com', '$2y$10$DKeT7SHUPGqFW6t7rfOJG.Y2Lv8ZziRpvgapW.oSLkGg5/ASKIOfW', '1', 'customer', '2019-11-19 08:04:55'),
('CUS005', 'Chethani', 'Wijesekara', '0774051964', '966592010v', './uploads/customer/966592010v.jpg', '72, Sri Sumangala Rd, Kalutara', 'chethaniwijesekara@gmail.com', '$2y$10$DatJAaMt73UuJfp5lHQTsuXgFxksHzm7NFZgoxXYM3N15.J6/0Zvi', '1', 'customer', '2019-11-19 09:01:02'),
('VEN001', 'kasun', 'guruge', '01145782', '96678542v', 'upload/vendor/96678542v.jpg', 'MAtara', 'kasun@gmail.com', '1234', '1', 'vendor', '2019-11-19 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `vendor`
--

CREATE TABLE `vendor` (
  `userId` varchar(10) NOT NULL,
  `businessRegNo` varchar(100) NOT NULL,
  `businessName` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `businessAddress` varchar(255) NOT NULL,
  `district` varchar(255) NOT NULL,
  `businessContactNo` varchar(100) NOT NULL,
  `businessEmail` varchar(255) NOT NULL,
  `categoryId` int(10) NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vendor`
--

INSERT INTO `vendor` (`userId`, `businessRegNo`, `businessName`, `description`, `businessAddress`, `district`, `businessContactNo`, `businessEmail`, `categoryId`, `created_at`) VALUES
('VEN001', 'BE098765', 'Shine Photography', 'Excellence in Photography', 'Colombo 06', 'Colombo', '0112457896', 'Shine@gmail.com', 1, '2019-11-19 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `vendortemp`
--

CREATE TABLE `vendortemp` (
  `tempId` int(100) NOT NULL,
  `firstName` varchar(255) NOT NULL,
  `lastName` varchar(255) NOT NULL,
  `contactNo` varchar(255) NOT NULL,
  `NIC` varchar(255) NOT NULL,
  `Image` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `encrypted_password` varchar(255) NOT NULL,
  `status` varchar(50) NOT NULL,
  `user_role` varchar(50) NOT NULL,
  `created_at` datetime NOT NULL,
  `businessRegNo` varchar(255) NOT NULL,
  `businessName` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `businessAddress` varchar(255) NOT NULL,
  `district` varchar(255) NOT NULL,
  `businessContactNo` varchar(50) NOT NULL,
  `businessEmail` varchar(255) NOT NULL,
  `categoryId` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vendortemp`
--

INSERT INTO `vendortemp` (`tempId`, `firstName`, `lastName`, `contactNo`, `NIC`, `Image`, `address`, `username`, `encrypted_password`, `status`, `user_role`, `created_at`, `businessRegNo`, `businessName`, `description`, `businessAddress`, `district`, `businessContactNo`, `businessEmail`, `categoryId`) VALUES
(1, 'kasun', 'Guruge', '011245758', '96678542v', 'upload/vendor/96678542v.jpg', 'MAtara', 'kasun@gmail.com', '1234', '1', 'vendor', '2019-11-19 00:00:00', 'BE098765', 'Shine Photography', 'Excellence in Photograph', 'Colombo 06', 'Colombo', '0112457896', 'Shine@gmail.com', '1'),
(4, 'Himasha ', 'Miurangee', '0112457824', '974589015v', './uploads/vendor/974589015v.jpg', '34, Hinatiyangala Kalutara', 'himashamw@gmail.com', '$2y$10$qq1t5JeRRYTzZ/iAvs46y.1T9xmRE5lGT4IiJOhINFubQCDibsMU6', '1', 'vendor', '2019-11-19 08:02:16', 'BE004', 'Click Wedding Photographers', 'Dreamlife Wedding Photos & Video is a well-recognized wedding photography and videography company in Colombo. The high quality service, passion and commitment we offer our clients will ensure the moments of your special day are captured so that you may re', 'Colombo 03', '5', '01145637854', 'Click123@gmail.com', '1'),
(5, 'Tiruni', 'Karunaratne', '0774051964', '974589015v', './uploads/vendor/974589015v.jpg', '34, Hinatiyangala Kalutara', 'tirunipk@gmail.com', '$2y$10$A0e1sxlYVVj3313lOnxUf.dl8feEZEmZo6zds0qg7Hd38F4u5Dd1y', '1', 'vendor', '2019-11-19 09:03:24', 'BE451234', '', 'To us, photography is an art of observation. It’s about finding something interesting in an ordinary place… we have found it has little to do with the things you see and everything to do with the way you see them.  Let us capture the beautiful moments of ', 'Colombo 03', '5', '0114789651', 'sdvsd@gmail.com', '1');

-- --------------------------------------------------------

--
-- Table structure for table `vendor_category`
--

CREATE TABLE `vendor_category` (
  `categoryId` int(100) NOT NULL,
  `categoryName` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`userId`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`userId`);

--
-- Indexes for table `vendor`
--
ALTER TABLE `vendor`
  ADD PRIMARY KEY (`userId`);

--
-- Indexes for table `vendortemp`
--
ALTER TABLE `vendortemp`
  ADD PRIMARY KEY (`tempId`);

--
-- Indexes for table `vendor_category`
--
ALTER TABLE `vendor_category`
  ADD PRIMARY KEY (`categoryId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `vendortemp`
--
ALTER TABLE `vendortemp`
  MODIFY `tempId` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `vendor_category`
--
ALTER TABLE `vendor_category`
  MODIFY `categoryId` int(100) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
